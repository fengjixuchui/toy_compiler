// package app;

// import static app.TokenType.*;
// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStreamReader;
// import java.nio.charset.Charset;
// import java.nio.file.Files;
// import java.nio.file.Paths;
// import java.util.List;
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.Map;

// class Token {
//     final TokenType type;
//     final String lexeme;
//     final Object literal;
//     final int line;

//     Token(TokenType type, String lexeme, Object literal, int line) {
//         this.type = type;
//         this.lexeme = lexeme;
//         this.literal = literal;
//         this.line = line;
//     }

//     public String toString() {
//         return type + " " + lexeme + " " + literal;
//     }
// }

// class Scanner {
//     private final String source;
//     private final List<Token> tokens = new ArrayList<>();
//     private int start = 0;
//     private int current = 0;
//     private int line = 1;
//     private static final Map<String, TokenType> keywords;

//     static {
//         keywords = new HashMap<>();
//         keywords.put("and", AND);
//         keywords.put("class", CLASS);
//         keywords.put("else", ELSE);
//         keywords.put("false", FALSE);
//         keywords.put("for", FOR);
//         keywords.put("fun", FUN);
//         keywords.put("if", IF);
//         keywords.put("nil", NIL);
//         keywords.put("or", OR);
//         keywords.put("print", PRINT);
//         keywords.put("return", RETURN);
//         keywords.put("super", SUPER);
//         keywords.put("this", THIS);
//         keywords.put("true", TRUE);
//         keywords.put("var", VAR);
//         keywords.put("while", WHILE);
//     }

//     Scanner(String source) {
//         this.source = source;
//     }

//     List<Token> scanTokens() {
//         while (!isAtEnd()) {
//             // We are at the beginning of the next lexeme.
//             start = current;
//             scanToken();
//         }

//         tokens.add(new Token(EOF, "", null, line));
//         return tokens;
//     }

//     private boolean isAtEnd() {
//         return current >= source.length();
//     }

//     private char peek() {
//         if (isAtEnd())
//             return '\0';
//         return source.charAt(current);
//     }

//     private void string() {
//         while (peek() != '"' && !isAtEnd()) {
//             if (peek() == '\n')
//                 line++;
//             advance();
//         }

//         // Unterminated string.
//         if (isAtEnd()) {
//             BookLox.error(line, "Unterminated string.");
//             return;
//         }

//         // The closing ".
//         advance();

//         // Trim the surrounding quotes.
//         String value = source.substring(start + 1, current - 1);
//         addToken(STRING, value);
//     }

//     private boolean isDigit(char c) {
//         return c >= '0' && c <= '9';
//     }

//     private void number() {
//         while (isDigit(peek()))
//             advance();

//         // Look for a fractional part.
//         if (peek() == '.' && isDigit(peekNext())) {
//             // Consume the "."
//             advance();
//             while (isDigit(peek()))
//                 advance();
//         }

//         addToken(NUMBER, Double.parseDouble(source.substring(start, current)));
//     }

//     private char peekNext() {
//         if (current + 1 >= source.length())
//             return '\0';
//         return source.charAt(current + 1);
//     }

//     private boolean match(char expected) {
//         if (isAtEnd())
//             return false;
//         if (source.charAt(current) != expected)
//             return false;

//         current++;
//         return true;
//     }

//     private boolean isAlpha(char c) {
//         return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
//     }

//     private boolean isAlphaNumeric(char c) {
//         return isAlpha(c) || isDigit(c);
//     }

//     private void identifier() {
//         while (isAlphaNumeric(peek()))
//             advance();

//         String text = source.substring(start, current);

//         TokenType type = keywords.get(text);
//         if (type == null)
//             type = IDENTIFIER;
//         addToken(type);
//     }

//     private void scanToken() {
//         char c = advance();
//         switch (c) {
//         case ' ':
//             break;
//         case '\r':
//             break;
//         case '\t':
//             break;
//         case '\n':
//             line++;
//             break;
//         case '(':
//             addToken(LEFT_PAREN);
//             break;
//         case ')':
//             addToken(RIGHT_PAREN);
//             break;
//         case '{':
//             addToken(LEFT_BRACE);
//             break;
//         case '}':
//             addToken(RIGHT_BRACE);
//             break;
//         case ',':
//             addToken(COMMA);
//             break;
//         case '.':
//             addToken(DOT);
//             break;
//         case '-':
//             addToken(MINUS);
//             break;
//         case '+':
//             addToken(PLUS);
//             break;
//         case ';':
//             addToken(SEMICOLON);
//             break;
//         case '*':
//             addToken(STAR);
//             break;
//         case '!':
//             addToken(match('=') ? BANG_EQUAL : BANG);
//             break;
//         case '=':
//             addToken(match('=') ? EQUAL_EQUAL : EQUAL);
//             break;
//         case '<':
//             addToken(match('=') ? LESS_EQUAL : LESS);
//             break;
//         case '>':
//             addToken(match('=') ? GREATER_EQUAL : GREATER);
//             break;
//         case '/':
//             if (match('/')) {
//                 // A comment goes until the end of the line.
//                 while (peek() != '\n' && !isAtEnd())
//                     advance();
//             } else {
//                 addToken(SLASH);
//             }
//             break;
//         case '"':
//             string();
//             break;

//         default:
//             if (isDigit(c)) {
//                 number();
//             } else if (isAlpha(c)) {
//                 identifier();
//             } else {
//                 BookLox.error(line, "Unexpected character.");
//             }
//             break;
//         }
//     }

//     private char advance() {
//         current++;
//         return source.charAt(current - 1);
//     }

//     private void addToken(TokenType type) {
//         addToken(type, null);
//     }

//     private void addToken(TokenType type, Object literal) {
//         String text = source.substring(start, current);
//         tokens.add(new Token(type, text, literal, line));
//     }

// }

// public class BookLox {
//     static boolean hadError = false;

//     private static void runFile(String path) throws IOException {
//         byte[] bytes = Files.readAllBytes(Paths.get(path));
//         run(new String(bytes, Charset.defaultCharset()));
//     }

//     private static void runPrompt() throws IOException {
//         InputStreamReader input = new InputStreamReader(System.in);
//         BufferedReader reader = new BufferedReader(input);
//         for (;;) {
//             System.out.print("> ");
//             run(reader.readLine());
//             hadError = false;
//         }
//     }

//     private static void run(String source) {
//         // Indicate an error in the exit code.
//         if (hadError)
//             System.exit(65);
//         Scanner scanner = new Scanner(source);
//         List<Token> tokens = scanner.scanTokens();

//         // For now, just print the tokens.
//         for (Token token : tokens) {
//             System.out.println(token);
//         }
//     }

//     static void error(int line, String message) {
//         report(line, "", message);
//     }

//     private static void report(int line, String where, String message) {
//         System.err.println("[line " + line + "] Error" + where + ": " + message);
//         hadError = true;
//     }

//     public static void main(String[] args) throws IOException {
//         if (args.length > 1) {
//             System.out.println("Usage: jlox [script]");
//             System.exit(64);
//         } else if (args.length == 1) {
//             runFile(args[0]);
//         } else {
//             runPrompt();
//         }
//     }
// }